// Minimal service worker: enables PWA installability, no offline caching logic
// to avoid interfering with the app's own localStorage-based state.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
